import { Button, Card } from "react-bootstrap";
import Loading from "../Loading/Loading";

const MostLikedProduct = (props) => {
  return (
    <>
      <Card style={{backgroundColor: "none"}}>
        <Card.Img variant="top" src={ props.loading ? <Loading/> : props.images?.[0]  }/>
        <Card.Body>
          <Card.Title>{props.title}</Card.Title>
          <Card.Text>
            {props.description}
          </Card.Text>
          <Button variant="primary">Fiyatı : {props.price} TL</Button>
        </Card.Body>
      </Card>
    </>
  );
};

export default MostLikedProduct;
