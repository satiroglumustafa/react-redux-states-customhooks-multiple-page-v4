import { Swiper, SwiperSlide } from "swiper/react";
import MostLikedProduct from "./MostLikedProduct";
import "swiper/css";
import "swiper/css/pagination";
import 'swiper/css/navigation';
import { Autoplay, Navigation, Pagination } from "swiper/modules";
const MostLikedProducts = ({ loadingDataApi, mostLikedDataApi }) => {
  const filteredItem = mostLikedDataApi.filter(item =>  item.price > 50);
  return (
    <>
      <Swiper
        navigation={true}
        spaceBetween={20}
        slidesPerView={4}
        pagination={{
          clickable: true,
        }}
        modules={[Autoplay, Pagination, Navigation]}
        breakpoints={{
          0: {
            slidesPerView: 1, // mobil
          },
          768: {
            slidesPerView: 2, // tablet
          },
          992: {
            slidesPerView: 3,
          },
          1200: {
            slidesPerView: 4,
          },
        }}
      >
        {filteredItem.map((mostLikedApiItem, index) => {
          return (
            <SwiperSlide key={index}>
              <MostLikedProduct
                {...mostLikedApiItem}
                loading={loadingDataApi}
              />
            </SwiperSlide>
          );
        })}
      </Swiper>
    </>
  );
};

export default MostLikedProducts;
