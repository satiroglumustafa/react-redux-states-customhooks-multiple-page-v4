import "./Footer.css";

const Footer = () => {
  return (
    <>
      <footer className="footer">
        <strong>Copyright Mustafa Şatıroğlu</strong> 2025 Tüm Hakları Saklıdır
      </footer>
    </>
  );
};

export default Footer;
