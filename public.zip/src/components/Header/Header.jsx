import { Col, Container, Form, Row } from "react-bootstrap";
import "./Header.css";
import {  Link } from "react-router-dom";
const Header = () => {
  return (
    <>
      <header className="header py-3">
        <Container>
          <Row>
            <Col xs={12}>
              <div className="d-flex align-items-center justify-content-between">
                <div className="menu">
                  <ul className="d-flex align-items-center gap-3">
                    <li>
                        <Link to='/'>Home</Link>
                    </li>
                    <li>
                        <Link to='about'>About</Link>
                    </li>
                    <li>
                        <Link to='categories'>Categories</Link> {/* preventScrollReset sayfa scroll durumu korunur */}
                    </li>
                  </ul>
                </div>
                <Form>
                  <Form.Check
                    type="switch"
                    id="custom-switch"
                    label=""
                  />
                </Form>
              </div>
            </Col>
          </Row>
        </Container>
      </header>
    </>
  );
};

export default Header;
