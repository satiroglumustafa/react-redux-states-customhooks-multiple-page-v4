import { createContext } from "react";

const ApiContext = createContext()

export default ApiContext